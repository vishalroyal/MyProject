package Practise;

public class StringToDouble {
    public static void main(String[] args) {
        // Original string
        String originalString = "596208.10";

        // Step 1: Remove non-numeric characters
        String numericString = originalString.replaceAll("[^0-9.]", "");

        // Step 2: Convert to double
        double result = Double.parseDouble(numericString);

        System.out.println(result);
    }
}
