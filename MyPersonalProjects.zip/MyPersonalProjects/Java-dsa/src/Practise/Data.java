package Practise;

public class Data {

    private String TransactionId;
    private String InsuranceAgent;
    private String CorporateCode;

    public String getTransactionId() {
        return TransactionId;
    }

    public void setTransactionId(String transactionId) {
        TransactionId = transactionId;
    }

    public String getInsuranceAgent() {
        return InsuranceAgent;
    }

    public void setInsuranceAgent(String insuranceAgent) {
        InsuranceAgent = insuranceAgent;
    }

    public String getCorporateCode() {
        return CorporateCode;
    }

    public void setCorporateCode(String corporateCode) {
        CorporateCode = corporateCode;
    }
}
