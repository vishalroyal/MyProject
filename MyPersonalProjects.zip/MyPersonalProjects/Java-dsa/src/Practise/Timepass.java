package Practise;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.regex.Pattern;

public class Timepass {

    public static void main(String grsa[]) throws Exception {

        /*
        String key="MIIGnTCCBYWgAwIBAgIIRe4eZ45JJ5kwDQYJKoZIhvcNAQELBQAwgbQxCzAJBgNVBAYTAlVTMRAwDgYDVQQIEwdB\n" +
                "cml6b25hMRMwEQYDVQQHEwpTY290dHNkYWxlMRowGAYDVQQKExFHb0RhZGR5LmNvbSwgSW5jLjEtMCsGA1UECxMk\n" +
                "aHR0cDovL2NlcnRzLmdvZGFkZHkuY29tL3JlcG9zaXRvcnkvMTMwMQYDVQQDEypHbyBEYWRkeSBTZWN1cmUgQ2Vy\n" +
                "dGlmaWNhdGUgQXV0aG9yaXR5IC0gRzIwHhcNMjIwNDA4MDcwMTQ3WhcNMjMwNDI2MTEyMDE3WjAeMRwwGgYDVQQD\n" +
                "DBMqLmJhbmRoYW5iYW5rLmNvLmluMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtkzo9crdf4kaHWKG\n" +
                "sF39lJUYCV/\n" +
                "6+zR732y3D579nJAlcWdJcnT4dWZRJBiAm+ktVRGmBd+QQ4XNWUyxzVADrL+obWCHpG3aVVZy8s3FahnCQnJJhfi\n" +
                "+s7FEhwGcz+B0RL2zK0gEZH8/bWjw1sF6yqOqA4OuJxw9FvSo0QuNvOl5vLXgoPAxm7KGMh1GuL//\n" +
                "unGkzdhNGpbtz7GZwZuQkEvI5unVOrlYrvs4yqx8INjPfkzVN2PseIrniPtFOaOQG+cHrtlC9PF55GFL8bE4fqO0\n" +
                "d6PXFX49GaKFw4pJe04CqrBiQtdsLYg4Lrl4Va+D0j/oG/\n" +
                "aQMzypins06QCQAwIDAQABo4IDRjCCA0IwDAYDVR0TAQH/\n" +
                "BAIwADAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwDgYDVR0PAQH/\n" +
                "BAQDAgWgMDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly9jcmwuZ29kYWRkeS5jb20vZ2RpZzJzMS0zOTk2LmNybDBdBgNVHSAEVjBUMEgGC2CGSAGG/\n" +
                "W0BBxcBMDkwNwYIKwYBBQUHAgEWK2h0dHA6Ly9jZXJ0aWZpY2F0ZXMuZ29kYWRkeS5jb20vcmVwb3NpdG9yeS8wC\n" +
                "AYGZ4EMAQIBMHYGCCsGAQUFBwEBBGowaDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZ29kYWRkeS5jb20vMEAGC\n" +
                "CsGAQUFBzAChjRodHRwOi8vY2VydGlmaWNhdGVzLmdvZGFkZHkuY29tL3JlcG9zaXRvcnkvZ2RpZzIuY3J0MB8GA\n" +
                "1UdIwQYMBaAFEDCvSeOzDSDMKIz1/tss/\n" +
                "C0LIDOMDEGA1UdEQQqMCiCEyouYmFuZGhhbmJhbmsuY28uaW6CEWJhbmRoYW5iYW5rLmNvLmluMB0GA1UdDgQWBB\n" +
                "QIGEiGB0jtEPzKlEXIZ7lpQBl9szCCAX0GCisGAQQB1nkCBAIEggFtBIIBaQFnAHYA6D7Q2j71BjUy51covIlryQ\n" +
                "PTy9ERa+zraeF3fW0GvW4AAAGAB/qjVwAABAMARzBFAiEA2+Xfp2DY94yE36CcxJMZGMWaJ/\n" +
                "rj6ZTvXOojlr5kX6QCIEmGbpNcmxrBItbis7t9+pOkXWTDt0s4R+8tYPEmuB1CAHUANc8ZG7+xbFe/\n" +
                "D61MbULLu7YnICZR6j/hKu+oA8M71kwAAAGAB/\n" +
                "qkqwAABAMARjBEAiAr4jNlezMknQv8UECDMrtmeyNC4V+90PCLThH9vxdsJAIgPixosN0nG865+OllyPEDz6uFol\n" +
                "xV9vTnTVjdQiQ+wb8AdgB6MoxU2LcttiDqOOBSHumEFnAyE4VNO9IrwTpXo1LrUgAAAYAH+qUdAAAEAwBHMEUCIE\n" +
                "fQwboYw+\n" +
                "+SzrBIqLdD7LFyQ+PgXhAQ5q5cPQ7ULqcjAiEA1VEMXFSu23vxSBFRv4dTvqs6S8tVhFNWqpuKhSnWM5MwDQYJKo\n" +
                "ZIhvcNAQELBQADggEBAF0rsdrGEcQMGRcJeUoAoz4x16L0nySyNn6C/\n" +
                "y1Tr7Bd6uoTVTLFtqVdpOZ1CQucV6fd+oMH+IeaLbrzas+16VN1/\n" +
                "VqDYztr33rNALMyscGOG9qk36Kl9SI3QyaYGfS3HvaGkDr7ou7lNl0y3VvxcybYzKBfJDpwSbIPVd9dJu2PB62Vs\n" +
                "ozHKGvR5VvomQHh3QNr3xnc/km14m+zvkRrmrvDD7fRU+gEZniNrhQU+lJqwgi/uJtrVVyrhu4H/\n" +
                "sdvOKMfcCElnJupC+g89Ig5gaHGZOaTHM4o9aWZo6qa8KwoQ09GLfapOIXL4Np7LbCNBYcqxBaQ5qwNjI2Hl8jFV\n" +
                "4c=";
        String encryptedCust=customEncrypt("330725229",key);

        String jsonString="{\"Data\":{\"TransactionId\":\"TPPI\",\"InsuranceAgent\":\"8\",\"CorporateCode\":\"NIVA\",\"InternalReferenceNumber\":\"3222306092090\",\"ExternalReferenceNumber\":\"yIZ4Hcxfm\",\"TransactionDate\":\"20231003\",\"TransactionType\":\"IFT\",\"BranchCode\":\"1011\",\"TransactionAmount\":{\"Amount\":\"1\",\"Currency\":\"INR\"},\"CreditAccountId\":\"10220005483806\",\"DebitAccountId\":\"52230041968776\",\"TransactionCreditComment\":{\"Comment\":[\"Insurance\",\"TPP\",\"Beneficiary\"]},\"TransactionDebitComment\":{\"Comment\":[\"TPP\",\"Insurance\",\"Beneficiary\"]},\"TransactionCreditSupportData\":[{\"Key\":\"ZTRTYP\",\"Value\":\"IFT\"},{\"Key\":\"YTRTYP\",\"Value\":\"IVT\"}],\"TransactionDebitSupportData\":{\"Key\":\"ZTRTYP\",\"Value\":\"IFT\"}}}";

        System.out.println(encryptedCust);
        System.out.println("decrypted "+decrypt(encryptedCust,key));

        Data data=new Data();
        data.setTransactionId("asw32a");
        data.setCorporateCode("asqa");
        data.setInsuranceAgent("aasqwqsa");


        //System.out.println(addBackslashToKeysAndValues());
    }

    public static String customEncrypt(final String plainValue, final String key) throws
            Exception {
        SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(key.toCharArray(), "1234".getBytes(), 65536, 256);
        SecretKey aesKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(),
                "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, aesKey);
        byte[] encryptedBytes = cipher.doFinal(plainValue.getBytes());
        byte[] iv = cipher.getIV();
        return new String(Base64.getEncoder().encode(encryptedBytes)) + "." + new
                String(Base64.getEncoder().encode(iv));
    }

    public static String decrypt(final String encryptedValue, final String key) throws
            Exception {
        SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(key.toCharArray(), "1234".getBytes(), 65536,
                256);
        SecretKey aesKey1 = new
                SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
        String[] str = encryptedValue.split(Pattern.quote("."));
        final byte[] decodedValue = Base64.getDecoder().decode(str[0]);
        final byte[] decodedIV = Base64.getDecoder().decode(str[1]);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        AlgorithmParameters.getInstance("AES");

        cipher.init(Cipher.DECRYPT_MODE, aesKey1, new IvParameterSpec(decodedIV));
        byte[] unencryptedBytes = cipher.doFinal(decodedValue);
        return new String(unencryptedBytes, "UTF-8");
    }

    public static String addBackslashToKeysAndValues(String jsonString) {
        StringBuilder modifiedJson = new StringBuilder();

        boolean inQuotes = false;
        for (int i = 0; i < jsonString.length(); i++) {
            char c = jsonString.charAt(i);

            if (c == '\"') {
                inQuotes = !inQuotes;
            }

            if (c == '\"' && !inQuotes) {
                modifiedJson.append("\\");
            }

            modifiedJson.append(c);
        }

        return modifiedJson.toString();
    }

         */
   String abc=     extractBase64FromBody("DefaultRequestBody(None,None,Some(O9vkvSyPHh7bec2OqMZqOb4063Cb8wrToW8TAHOxzu3NsjGRkDZxGT03PoSyRY37PN2uSXnkvu2y5GpToq6NSV16zl7VBNjQYkv3hKIvM1l2Gz3D3XsO9HM6+OmB2PPq5CZtTWZZIlSlbC51TYalExoJlbrjrwrCZTg9bFVU),None,None,None,false) ");
           System.out.println(abc);
           String encrypted=encrypt("{\n" +
                   "    \"channelid\": \"INTB\",\n" +
                   "    \"ProductCode\": \"LIFE\",\n" +
                   "    \"SessionID\": \"ONQ61WJUYhUWbDgGmhVzUg==\",\n" +
                   "    \"CustID\": \"8080515100\"\n" +
                   "}","QeThWmZq3t6w9z$C&F)J@NcRfUjXn2r5");
        System.out.println(encrypted);

       // String deCrypted=decrypt(abc,"QeThWmZq3t6w9z$C&F)J@NcRfUjXn2r5");
        //System.out.println(deCrypted);

        String deCryptedCustom=decrypt("O9vkvSyPHh7bec2OqMZqOb4063Cb8wrTo/W8TAHOxzu3NsjGRkDZxGT03PoSyRY37/PN2uSXnkvu2y5GpToq6NSV16zl7VBNjQYkv3hKIvM1l2Gz3D3XsO9HM6+OmB2PPq5CZt+TWZZIlSlbC51TYalExoJlbrjrwrCZTg9bFVWW9Um0VKsIsuGKuD6eZOUq","QeThWmZq3t6w9z$C&F)J@NcRfUjXn2r5");
        System.out.println("custom "+ deCryptedCustom);
    }

    private static String extractBase64FromBody(String requestBody) {
        // Assuming the request body is formatted as DefaultRequestBody(None,None,Some(base64data),None,None,None,false)
        // Extract the part that contains the Base64 encoded data
        String[] parts = requestBody.split(",");
        for (String part : parts) {
            if (part.contains("Some(")) {
                return part.replace("Some(", "").replace(")", "").trim();
            }
        }
        return "";
    }

    public static String encrypt(String data, String secretKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Key key = generateKey(secretKey);
        Cipher c = Cipher.getInstance("AES");
        c.init(1, key);
        byte[] encVal = c.doFinal(data.getBytes());
        return new String(Base64.getEncoder().encode(encVal));
    }
    public static String decrypt(String encryptedData, String secretKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Key key = generateKey(secretKey);
        Cipher c = Cipher.getInstance("AES");
        c.init(2, key);
        byte[] decordedValue = Base64.getDecoder().decode(encryptedData);
        byte[] decValue = c.doFinal(decordedValue);
        return new String(decValue);
    }

    private static Key generateKey(String secretKey) {
        return new SecretKeySpec(secretKey.getBytes(), "AES");
    }

}



