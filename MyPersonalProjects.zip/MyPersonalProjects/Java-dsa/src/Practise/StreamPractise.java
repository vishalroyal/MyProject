package Practise;

import StreamsAPI.Employee;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamPractise {

    public static void main(String args[]) {

        Employee e1 = new Employee("vishal", "mumbai", "34", 5000.00);
        Employee e2 = new Employee("kishal", "pune", "35", 7000.00);
        Employee e3 = new Employee("aman", "mumbai", "36", 4000.00);

        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(e1);
        employeeList.add(e2);
        employeeList.add(e3);

       Map<String ,List<Employee>> groupList= employeeList.stream().collect(Collectors.groupingBy(Employee::getCity));
       groupList.forEach((key,value)-> System.out.println(key +" " +value));

       String [] abc={"vishal","her","vishal"};
       long count=Arrays.stream(abc).filter(e->"vishal".equalsIgnoreCase(e)).count();
        System.out.println(count);

        List<String> stringList = Arrays.asList("vishal","bhavna","vish","bhav","vishal","bhavna");
        Map<String,Long> abca=stringList.stream().collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
        System.out.println("name and its occurances "+ abca);

        String s="helllo world";
        Map<String,Long> abcad=Arrays.stream(s.split("")).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
        System.out.println("name and its occurances "+ abcad);

        Map<String, Optional<Employee>> employeeSalary= employeeList.stream().collect(Collectors.groupingBy(Employee::getCity,Collectors.maxBy(Comparator.comparing(Employee::getSalary))));
        employeeSalary.forEach((key,value)-> System.out.println("Employee salary citywise "+key +"  "+ value ));

        List<String> eCity=employeeList.stream().map(Employee::getCity).collect(Collectors.toList());
        System.out.println("cities "+ eCity);

        String s1="helllo world";
        Map<String,Long> abcadw=Arrays.stream(s.split("")).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
        String abx=abcadw.entrySet().stream().filter(e->e.getValue()>1).map(e->e.getKey()).findFirst().get();
        String aba=abcadw.entrySet().stream().filter(e->e.getValue()==1).map(e->e.getKey()).findFirst().get();

        System.out.println(abx+" "+aba);

        String abcs="vishal";
        String abcsa= Stream.of(abcs).map(word-> new StringBuilder(word).reverse()).collect(Collectors.joining(""));
        System.out.println(abcsa);
    }
}
