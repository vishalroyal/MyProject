package Practise;

import java.lang.reflect.Array;
import java.util.*;

public class HashDinpractise {

    public static void main(String args[]) {
        int arr[] = {12, 2, 38, 16};
        int k = 50;
        int count=0;
        Map<Integer,Integer> mainMap=new HashMap<>();

        for (int i = 0; i <arr.length;i++)
        {
            int target=k-arr[i];
            if(mainMap.containsKey(target))
                count++;
            else
                mainMap.put(arr[i],1);

        }
        System.out.println(count);



    String expression1 = "{[()]}";
    String expression2 = "([)]";
        System.out.println(isBalanced(expression1));
        System.out.println(isBalanced(expression2));



        int arr1[] = { 900, 940, 950, 1100, 1500, 1800 };
        int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
        int n = 3;
        System.out.println(findPlatform(arr, dep, n));

    }
    public static int findPlatform(int arr1[], int dep[],
                                   int n)
    {
        Arrays.sort(arr1);
        Arrays.sort(dep);
        int res=0;
        int count=0;

        int i=0,j=0;
        while(i<n)
        {
            if(arr1[i]<=dep[j])
            {
                count++;
                res=Math.max(res,count);
                i++;
            }
            else if(arr1[i]>dep[j])
            {
                count--;
                j++;
            }
        }
        return res;



    }

    static boolean isBalanced(String exp)
    {
        Stack<Character> as=new Stack<>();

        for(int i=0;i<exp.toCharArray().length;i++)
        {
            char ch=exp.charAt(i);
            if(isOpening(ch))
                as.push(ch);
            else
            {
                if(as.isEmpty() || !isMatching(as.peek(),ch))
                    return false;
                else
                    as.pop();
            }
        }
        return as.isEmpty();
    }

    static boolean isOpening(char exp)
    {
        return exp =='(' || exp =='{' || exp == '[';
    }

    static boolean isMatching(char a , char b)
    {
        return (a=='(' && b==')' || a=='{' && b=='}' || a=='[' && b==']');
    }

}
