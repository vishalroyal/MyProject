package SqlQueries;

public class SqlQueries {

    //Top sql queries asked in interview

    /*

       1) second highest salary from employeeinfo table
       --> select * from employeeinfo order by salary desc limit 1,1;

       2) select duplicate records from table
       --> select * from employeeinfo group by empid having count(empid)>1;

       3) even records
       --> select * from employeeinfo where mod( empid,2) =0;

       4) first min record
       --> select * from employeeinfo where empid = (select MIN (empid)
       from employeeinfo);

       5) last record
       --> select * from employeeinfo where empid = (select MAX (empid)
       from employeeinfo);

       6) name of employess working in same deprt.
       --> select DISTINCT E.name ,E1.department from employeeinfo E , department E1
       on E.depid = E1.depid and E.empid!=E1.empid;

       7) fetch last 3 reords in asc order
       --> select * from (select * from employeeinfo order by empId desc limit 3)
       temp order by empId asc;

       8) delete duplicate record
       --> delete E1 from employeeinfo E1,employeeinfo E2
           where E1.email=E2.email and E1.Id> E2.Id;

       9) fetch half records from table
       --> select * from emloyeeinfo where id <= (select count(id)/2 from employeeinfo);

       10) find the name of the dept where more than 2 employees are working
       --> select d.dep_name from department d left join employeeinfo e
           ON d.deptId=e.deptId group by e.deptId having count(e.deptId) >2;


       11) calculate avg salary of each deprtment which is higher than 75000 find dept name in desc

      --> select d.dept_name , avg(salary) from employee e left join department d ON
          e.deptid =d.dept_id group by e.dept_id having avg(e.salary)>75000
           order by d.dept_name desc

        12) find the manager name and employee and city who belongs to same city
        --> select m.name , e.name ,e.city from employeeinfo e left join manager m ON
            e.mid=m.mid where e.city = m.city;

        13) employee name salary betwn 35000 and 90000 with depet and manager name
        --> select e.name ,d.dept_name,m.name from employee e left join department d
            ON e.deptId=d.deptId left join manager m ON e.mid=m.id where e.salary betwwen 35000 and 90000 ;
     */

}
