package com.JavaStream.JavaStream;


import java.util.Collections;
import java.util.List;

public class Customer {

    String name;
    String id ;
    List<String> Phone;

    public Customer(String name, String id, String phone) {
        this.name = name;
        this.id = id;
        Phone = Collections.singletonList(phone);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return Phone.toString();
    }

    public void setPhone(String phone) {
        Phone = Collections.singletonList(phone);
    }
}
