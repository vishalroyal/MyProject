package com.JavaStream.JavaStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootApplication
public class JavaStreamApplication {

	 public List<Customer> getData(){
		 return Stream.of(new Customer("vishal","12", Arrays.asList("1243523","2433241").toString()),
				 new Customer("kaushik","14",Arrays.asList("98473231","3142124121")));
	 }


	public static void main(String[] args) {
		SpringApplication.run(JavaStreamApplication.class, args);

		List<Integer> abc=new ArrayList<>();
		abc.add(1);
		abc.add(3);
		abc.add(2);

		abc.stream().filter(q-> q.equals(3)).forEach(e->System.out.println(e));
		abc.stream().map(i->i+2).collect(Collectors.toList());
		//List<Integer>abv=abc.stream().mapToInt(e->e).average().collect(Collectors.toList());


	}

}
